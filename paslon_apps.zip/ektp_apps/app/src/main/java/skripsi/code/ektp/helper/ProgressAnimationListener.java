package skripsi.code.ektp.helper;

/**
 * Created by eralpyucel on 11/12/2016.
 */

public interface ProgressAnimationListener {

    void onValueChanged(float value);
    void onAnimationEnd();
}
